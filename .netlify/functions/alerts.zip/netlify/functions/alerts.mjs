
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/alerts.mjs
import { ObjectId } from "mongodb";

// netlify/lib/mongodb.mjs
import { MongoClient } from "mongodb";
var cachedClient = null;
var cachedDb = null;
async function getDb() {
  if (cachedClient && cachedDb) {
    return cachedDb;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI environment variable is not set");
  }
  const client = new MongoClient(uri, {
    maxPoolSize: 1,
    serverSelectionTimeoutMS: 5e3
  });
  await client.connect();
  const dbName = process.env.MONGODB_DB_NAME || "stock_analyzer";
  const db = client.db(dbName);
  cachedClient = client;
  cachedDb = db;
  return db;
}

// netlify/lib/firebase-admin.mjs
import admin from "firebase-admin";
function initFirebase() {
  if (admin.apps.length > 0) return;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKeyB64 = process.env.FIREBASE_PRIVATE_KEY;
  if (!projectId || !clientEmail || !privateKeyB64) {
    throw new Error("Firebase env vars missing: " + (!projectId ? "FIREBASE_PROJECT_ID " : "") + (!clientEmail ? "FIREBASE_CLIENT_EMAIL " : "") + (!privateKeyB64 ? "FIREBASE_PRIVATE_KEY " : ""));
  }
  let privateKey;
  try {
    privateKey = Buffer.from(privateKeyB64, "base64").toString("utf-8");
  } catch (e) {
    privateKey = privateKeyB64.replace(/\\n/g, "\n");
  }
  admin.initializeApp({
    credential: admin.credential.cert({ projectId, clientEmail, privateKey })
  });
}
async function verifyToken(req) {
  initFirebase();
  const authHeader = req.headers.get("authorization") || "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) throw new Error("Missing or invalid Authorization header");
  const decoded = await admin.auth().verifyIdToken(match[1]);
  return {
    uid: decoded.uid,
    email: decoded.email || null,
    name: decoded.name || null,
    picture: decoded.picture || null,
    phone: decoded.phone_number || null
  };
}

// netlify/functions/alerts.mjs
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: CORS_HEADERS });
}
function error(message, status = 400) {
  return json({ error: message }, status);
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  try {
    const user = await verifyToken(req);
    const db = await getDb();
    switch (action) {
      case "create":
        return await handleCreate(db, user, req);
      case "list":
        return await handleList(db, user);
      case "cancel":
        return await handleCancel(db, user, req);
      case "history":
        return await handleHistory(db, user);
      default:
        return error("Invalid action", 400);
    }
  } catch (err) {
    if (err.message.includes("Authorization")) {
      return error("Unauthorized", 401);
    }
    console.error("Alerts error:", err.message, err.stack);
    return error("Server error: " + err.message, 500);
  }
}
async function handleCreate(db, user, req) {
  const body = await req.json();
  const { symbol, name, targetPrice, condition, currency } = body;
  if (!symbol || !targetPrice || !condition) {
    return error("Missing required fields: symbol, targetPrice, condition");
  }
  if (!["above", "below"].includes(condition)) {
    return error('Condition must be "above" or "below"');
  }
  const activeCount = await db.collection("alerts").countDocuments({ uid: user.uid, status: "active" });
  if (activeCount >= 10) {
    return error("Maximum of 10 active alerts reached. Cancel an existing alert to create a new one.");
  }
  const alert = {
    uid: user.uid,
    email: user.email,
    symbol: symbol.toUpperCase(),
    name: name || symbol,
    targetPrice: parseFloat(targetPrice),
    condition,
    currency: currency || "USD",
    status: "active",
    createdAt: /* @__PURE__ */ new Date(),
    updatedAt: /* @__PURE__ */ new Date(),
    lastCheckedAt: null,
    lastCheckedPrice: null
  };
  const result = await db.collection("alerts").insertOne(alert);
  return json({
    success: true,
    alert: { ...alert, _id: result.insertedId }
  });
}
async function handleList(db, user) {
  const alerts = await db.collection("alerts").find({ uid: user.uid, status: "active" }).sort({ createdAt: -1 }).toArray();
  return json({ success: true, alerts });
}
async function handleCancel(db, user, req) {
  const body = await req.json();
  const { alertId } = body;
  if (!alertId) {
    return error("Missing alertId");
  }
  const result = await db.collection("alerts").findOneAndUpdate(
    {
      _id: new ObjectId(alertId),
      uid: user.uid,
      status: "active"
    },
    {
      $set: {
        status: "cancelled",
        updatedAt: /* @__PURE__ */ new Date()
      }
    },
    { returnDocument: "after" }
  );
  if (!result) {
    return error("Alert not found or already cancelled", 404);
  }
  return json({ success: true, alert: result });
}
async function handleHistory(db, user) {
  const history = await db.collection("alert_history").find({ uid: user.uid }).sort({ triggeredAt: -1 }).limit(50).toArray();
  return json({ success: true, history });
}
export {
  handler as default
};
