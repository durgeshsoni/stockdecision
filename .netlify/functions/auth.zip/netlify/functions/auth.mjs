
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/mongodb.mjs
import { MongoClient } from "mongodb";
var cachedClient = null;
var cachedDb = null;
async function getDb() {
  if (cachedClient && cachedDb) {
    return cachedDb;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI environment variable is not set");
  }
  const client = new MongoClient(uri, {
    maxPoolSize: 1,
    serverSelectionTimeoutMS: 5e3
  });
  await client.connect();
  const dbName = process.env.MONGODB_DB_NAME || "stock_analyzer";
  const db = client.db(dbName);
  cachedClient = client;
  cachedDb = db;
  return db;
}

// netlify/lib/firebase-admin.mjs
import admin from "firebase-admin";
function initFirebase() {
  if (admin.apps.length > 0) return;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKeyB64 = process.env.FIREBASE_PRIVATE_KEY;
  if (!projectId || !clientEmail || !privateKeyB64) {
    throw new Error("Firebase env vars missing: " + (!projectId ? "FIREBASE_PROJECT_ID " : "") + (!clientEmail ? "FIREBASE_CLIENT_EMAIL " : "") + (!privateKeyB64 ? "FIREBASE_PRIVATE_KEY " : ""));
  }
  let privateKey;
  try {
    privateKey = Buffer.from(privateKeyB64, "base64").toString("utf-8");
  } catch (e) {
    privateKey = privateKeyB64.replace(/\\n/g, "\n");
  }
  admin.initializeApp({
    credential: admin.credential.cert({ projectId, clientEmail, privateKey })
  });
}
async function verifyToken(req) {
  initFirebase();
  const authHeader = req.headers.get("authorization") || "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) throw new Error("Missing or invalid Authorization header");
  const decoded = await admin.auth().verifyIdToken(match[1]);
  return {
    uid: decoded.uid,
    email: decoded.email || null,
    name: decoded.name || null,
    picture: decoded.picture || null,
    phone: decoded.phone_number || null
  };
}

// netlify/functions/auth.mjs
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: CORS_HEADERS });
}
function error(message, status = 400) {
  return json({ error: message }, status);
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  try {
    const user = await verifyToken(req);
    const db = await getDb();
    switch (action) {
      case "login":
        return await handleLogin(db, user, req);
      case "profile":
        return await handleProfile(db, user);
      case "update":
        return await handleUpdate(db, user, req);
      case "delete":
        return await handleDelete(db, user);
      default:
        return error("Invalid action", 400);
    }
  } catch (err) {
    if (err.message.includes("Authorization")) {
      return error("Unauthorized", 401);
    }
    console.error("Auth error:", err);
    return error("Internal server error", 500);
  }
}
async function handleLogin(db, user, req) {
  const now = /* @__PURE__ */ new Date();
  const result = await db.collection("users").findOneAndUpdate(
    { uid: user.uid },
    {
      $set: {
        email: user.email,
        name: user.name,
        picture: user.picture,
        phone: user.phone,
        lastLoginAt: now,
        updatedAt: now
      },
      $setOnInsert: {
        uid: user.uid,
        createdAt: now,
        preferences: {
          defaultMode: "basic",
          emailAlerts: true
        }
      }
    },
    { upsert: true, returnDocument: "after" }
  );
  return json({ success: true, user: result });
}
async function handleProfile(db, user) {
  const profile = await db.collection("users").findOne({ uid: user.uid });
  if (!profile) {
    return error("User not found", 404);
  }
  return json({ success: true, user: profile });
}
async function handleUpdate(db, user, req) {
  const body = await req.json();
  const updates = {};
  if (body.defaultMode !== void 0) {
    updates["preferences.defaultMode"] = body.defaultMode;
  }
  if (body.emailAlerts !== void 0) {
    updates["preferences.emailAlerts"] = body.emailAlerts;
  }
  if (Object.keys(updates).length === 0) {
    return error("No valid fields to update");
  }
  updates.updatedAt = /* @__PURE__ */ new Date();
  const result = await db.collection("users").findOneAndUpdate(
    { uid: user.uid },
    { $set: updates },
    { returnDocument: "after" }
  );
  if (!result) {
    return error("User not found", 404);
  }
  return json({ success: true, user: result });
}
async function handleDelete(db, user) {
  const uid = user.uid;
  await Promise.all([
    db.collection("users").deleteOne({ uid }),
    db.collection("alerts").deleteMany({ uid }),
    db.collection("alert_history").deleteMany({ uid }),
    db.collection("search_history").deleteMany({ uid }),
    db.collection("watchlist").deleteMany({ uid })
  ]);
  return json({ success: true, message: "Account and all data deleted" });
}
export {
  handler as default
};
