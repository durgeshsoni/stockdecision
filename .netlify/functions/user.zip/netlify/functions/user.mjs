
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/mongodb.mjs
import { MongoClient } from "mongodb";
var cachedClient = null;
var cachedDb = null;
async function getDb() {
  if (cachedClient && cachedDb) {
    return cachedDb;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI environment variable is not set");
  }
  const client = new MongoClient(uri, {
    maxPoolSize: 1,
    serverSelectionTimeoutMS: 5e3
  });
  await client.connect();
  const dbName = process.env.MONGODB_DB_NAME || "stock_analyzer";
  const db = client.db(dbName);
  cachedClient = client;
  cachedDb = db;
  return db;
}

// netlify/lib/firebase-admin.mjs
import admin from "firebase-admin";
function initFirebase() {
  if (admin.apps.length > 0) return;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKeyB64 = process.env.FIREBASE_PRIVATE_KEY;
  if (!projectId || !clientEmail || !privateKeyB64) {
    throw new Error("Firebase env vars missing: " + (!projectId ? "FIREBASE_PROJECT_ID " : "") + (!clientEmail ? "FIREBASE_CLIENT_EMAIL " : "") + (!privateKeyB64 ? "FIREBASE_PRIVATE_KEY " : ""));
  }
  let privateKey;
  try {
    privateKey = Buffer.from(privateKeyB64, "base64").toString("utf-8");
  } catch (e) {
    privateKey = privateKeyB64.replace(/\\n/g, "\n");
  }
  admin.initializeApp({
    credential: admin.credential.cert({ projectId, clientEmail, privateKey })
  });
}
async function verifyToken(req) {
  initFirebase();
  const authHeader = req.headers.get("authorization") || "";
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) throw new Error("Missing or invalid Authorization header");
  const decoded = await admin.auth().verifyIdToken(match[1]);
  return {
    uid: decoded.uid,
    email: decoded.email || null,
    name: decoded.name || null,
    picture: decoded.picture || null,
    phone: decoded.phone_number || null
  };
}

// netlify/functions/user.mjs
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: CORS_HEADERS });
}
function error(message, status = 400) {
  return json({ error: message }, status);
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  try {
    const user = await verifyToken(req);
    const db = await getDb();
    switch (action) {
      case "search":
        return await handleSearch(db, user, req);
      case "history":
        return await handleHistory(db, user);
      case "frequent":
        return await handleFrequent(db, user);
      case "watchlist":
        return await handleWatchlist(db, user);
      case "watchlist-add":
        return await handleWatchlistAdd(db, user, req);
      case "watchlist-remove":
        return await handleWatchlistRemove(db, user, req);
      case "dashboard":
        return await handleDashboard(db, user);
      default:
        return error("Invalid action", 400);
    }
  } catch (err) {
    if (err.message.includes("Authorization")) {
      return error("Unauthorized", 401);
    }
    console.error("User error:", err.message, err.stack);
    return error("Server error: " + err.message, 500);
  }
}
async function handleSearch(db, user, req) {
  const body = await req.json();
  const { symbol, name } = body;
  if (!symbol) {
    return error("Missing required field: symbol");
  }
  await db.collection("search_history").insertOne({
    uid: user.uid,
    symbol: symbol.toUpperCase(),
    name: name || symbol,
    searchedAt: /* @__PURE__ */ new Date()
  });
  return json({ success: true });
}
async function handleHistory(db, user) {
  const history = await db.collection("search_history").find({ uid: user.uid }).sort({ searchedAt: -1 }).limit(30).toArray();
  return json({ success: true, history });
}
async function handleFrequent(db, user) {
  const frequent = await db.collection("search_history").aggregate([
    { $match: { uid: user.uid } },
    {
      $group: {
        _id: "$symbol",
        name: { $last: "$name" },
        count: { $sum: 1 },
        lastSearched: { $max: "$searchedAt" }
      }
    },
    { $sort: { count: -1 } },
    { $limit: 10 },
    {
      $project: {
        _id: 0,
        symbol: "$_id",
        name: 1,
        count: 1,
        lastSearched: 1
      }
    }
  ]).toArray();
  return json({ success: true, frequent });
}
async function handleWatchlist(db, user) {
  const watchlist = await db.collection("watchlist").find({ uid: user.uid }).sort({ addedAt: -1 }).toArray();
  return json({ success: true, watchlist });
}
async function handleWatchlistAdd(db, user, req) {
  const body = await req.json();
  const { symbol, name } = body;
  if (!symbol) {
    return error("Missing required field: symbol");
  }
  const upperSymbol = symbol.toUpperCase();
  const count = await db.collection("watchlist").countDocuments({ uid: user.uid });
  if (count >= 30) {
    return error("Maximum of 30 watchlist items reached. Remove an item to add a new one.");
  }
  const existing = await db.collection("watchlist").findOne({ uid: user.uid, symbol: upperSymbol });
  if (existing) {
    return error("Stock already in watchlist");
  }
  const item = {
    uid: user.uid,
    symbol: upperSymbol,
    name: name || symbol,
    addedAt: /* @__PURE__ */ new Date()
  };
  await db.collection("watchlist").insertOne(item);
  return json({ success: true, item });
}
async function handleWatchlistRemove(db, user, req) {
  const body = await req.json();
  const { symbol } = body;
  if (!symbol) {
    return error("Missing required field: symbol");
  }
  const result = await db.collection("watchlist").deleteOne({
    uid: user.uid,
    symbol: symbol.toUpperCase()
  });
  if (result.deletedCount === 0) {
    return error("Stock not found in watchlist", 404);
  }
  return json({ success: true });
}
async function handleDashboard(db, user) {
  const [recentSearches, watchlist, activeAlerts, frequentStocks] = await Promise.all([
    db.collection("search_history").find({ uid: user.uid }).sort({ searchedAt: -1 }).limit(10).toArray(),
    db.collection("watchlist").find({ uid: user.uid }).sort({ addedAt: -1 }).toArray(),
    db.collection("alerts").find({ uid: user.uid, status: "active" }).sort({ createdAt: -1 }).toArray(),
    db.collection("search_history").aggregate([
      { $match: { uid: user.uid } },
      {
        $group: {
          _id: "$symbol",
          name: { $last: "$name" },
          count: { $sum: 1 },
          lastSearched: { $max: "$searchedAt" }
        }
      },
      { $sort: { count: -1 } },
      { $limit: 10 },
      {
        $project: {
          _id: 0,
          symbol: "$_id",
          name: 1,
          count: 1,
          lastSearched: 1
        }
      }
    ]).toArray()
  ]);
  return json({
    success: true,
    dashboard: {
      recentSearches,
      watchlist,
      activeAlerts,
      frequentStocks
    }
  });
}
export {
  handler as default
};
